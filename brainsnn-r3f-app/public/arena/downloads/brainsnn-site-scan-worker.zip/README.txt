BrainSNN private site scan worker
Read docs/site-scan-worker.md first.
The kit contains no credentials, customer captures, model weights or GPU software.
