BrainSNN LIBERO worker kit
Read docs/arena-worker.md first.
The model server and physics worker require separately installed dependencies, model weights and configured credentials. This archive contains no weights or access tokens.
