# BrainSNN Street Studio — model and source package

This package contains the baseline model, editable object data, evidence
metadata, compact source inputs, and reproducible asset/export scripts. The
interactive editor is provided separately through the Street Studio app.

## Open or import the model

- **Visual model:** `dist/exports/BrainSNN_Street_Studio.glb`. Import into a
  glTF-compatible viewer or DCC/engine. It contains 272 named meshes with
  building/component hierarchy and source metadata. It is about 2.2 MB.
- **Simulation interchange:** `dist/exports/BrainSNN_Street_Studio.usda`.
  Open in a compatible OpenUSD application. It includes metre/Y-up geometry,
  explicit colliders, material bindings, semantic labels and one configured
  20 kg rigid body. It is about 3.6 MB. A target runtime must still be checked.
- **Editable scene:** `dist/assets/scene.json`. This is the object contract used
  by the browser editor and exporter. Structural positions are fixed in the
  demonstration; authored colors and the barrier can be changed in the app.
- **Evidence and limitations:** `dist/exports/manifest.json` and
  `asset_pipeline/README.md`.

All dimensions are in metres. X is grid east, Y is up and Z is minus grid
north. The geographic origin is 43.7234276, -79.4438620. The exact projected and
vertical origins are stored in `scene.json` and the export manifest.

## What is reference data, and what is authored?

The scene retains 168 municipal reference forms, including six courtyard
holes. Forms 130159, 130140 and 130143 receive authored façade parts. The
municipal release is from 2025, with site-plan heights or older LiDAR-derived
heights; current as-built status is unverified. The terrain is a 2 m
interpretation of classified-ground returns from the 2023 TRCA/NRCan LiDAR.

Windows, decorative doors, roof caps, finish panels, steps, sidewalks, curb,
lane, trees and barrier are explicitly authored assumptions. They are not
measured features reconstructed from the uploaded video. The video has not
been registered to this scene. There are no invented photo matches or photo
textures, and there are no modeled interiors.

The three detailed building bases are assumed placements on the interpreted
terrain; municipal source Z does not establish an absolute vertical datum.
Other context buildings use a flat local baseline.

The road, sidewalk and curb ribbons are divided at spacing no greater than 1 m
along and across, and clipped to the terrain-triangle boundaries. They follow
the interpreted terrain with configured offsets of 5 cm for the lane and
10 cm for sidewalk/curb, avoiding surface intersections. These are authored
surface offsets, not measured curb heights.

## Live exports and hidden objects

The browser can export its edited scene as GLB or USDA. The standalone
`dist/usd-export.mjs` exports the current `scene.json` shape using
`exportSceneUSD(sceneData)`.

Setting `object.visible` to false hides that object's rendered USD mesh while
preserving enabled collision and its physics settings. A hidden building does
not become a traversable space merely because its visual is hidden. The GLB
export contains visible graphics and excludes hidden visuals; GLB does not
replace the explicit USD physics scene.

## Reproduce and check

Install `asset_pipeline/requirements.txt` in a Python environment, then run:

```sh
python asset_pipeline/build_assets.py
node --test tests/export-contract.test.mjs
python asset_pipeline/validate_exports.py
```

The retained 1.5 MB `asset_pipeline/ground_patch.npz` makes the terrain build
portable without requiring the original 62 MB LAZ. Source municipal GeoJSON,
source metadata and the derived grid are under `dist/assets/reference/`.
No paid API or network request is made by the build. Dependencies need to be
installed separately. Python packages and the full LAZ are not included.

The JavaScript tests check identities, hierarchy, configured physics, changed
barrier/material values, courtyard collider type and visibility behavior.
The Python check independently opens the USDA with usd-core, including an
edited/recolored/hidden barrier. Validation results are included in
`asset_pipeline/validation.json`.

The checks establish data and serialization consistency. They do not claim
measured physical accuracy, verified current-site geometry, or a successful
Isaac Sim/Unreal/Unity sensor or dynamics run.

## Attribution

Contains information licensed under the Open Government Licence – Toronto.
City of Toronto 3D Massing, 2025 release.

Contains information licensed under the Open Government Licence – Canada.
Toronto and Region Conservation Authority LiDAR, distributed by Natural
Resources Canada (CanElevation), GTA_2023.

Original source URLs, licence URLs, acquisition evidence and processing details
are retained in the manifests and source-reference files. `PACKAGE_MANIFEST.json`
lists the included files and their SHA-256 checksums.
