"""Parse baseline and changed/hidden live USD exports with the OpenUSD library."""
import json
import pathlib
import subprocess
import tempfile

import numpy as np
import trimesh
from pxr import Sdf, Usd, UsdGeom, UsdPhysics, UsdSemantics

ROOT=pathlib.Path(__file__).resolve().parents[1]
SCENE=json.loads((ROOT/'dist/assets/scene.json').read_text())


def inspect(path, *, edited=False):
    stage=Usd.Stage.Open(str(path))
    assert stage
    meshes=[p for p in stage.Traverse() if p.IsA(UsdGeom.Mesh)]
    colliders=[p for p in meshes if p.HasAPI(UsdPhysics.CollisionAPI)]
    bodies=[p for p in stage.Traverse() if p.HasAPI(UsdPhysics.RigidBodyAPI)]
    assert len(meshes)==len(SCENE['objects'])
    assert len(colliders)==sum(o['collider']['enabled'] for o in SCENE['objects'])
    assert len(bodies)==1
    assert UsdGeom.GetStageMetersPerUnit(stage)==1
    assert UsdGeom.GetStageUpAxis(stage)=='Y'
    assert UsdPhysics.MassAPI(bodies[0]).GetMassAttr().Get()==20
    for prim in colliders:
        assert prim.GetRelationship('material:binding:physics').GetTargets()==[Sdf.Path('/World/Materials/ConfiguredContact')]
        assert UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get()
        if prim.GetParent().GetCustomDataByKey('stableId').startswith('bldg-'):
            assert UsdPhysics.MeshCollisionAPI(prim).GetApproximationAttr().Get()=='none'
        assert np.isfinite(np.asarray(UsdGeom.Mesh(prim).GetPointsAttr().Get())).all()
    body=bodies[0]
    assert UsdSemantics.LabelsAPI(body,'class').GetLabelsAttr().Get()==['barrier']
    if edited:
        assert np.allclose(body.GetAttribute('xformOp:translate').Get(),[12.25,1.125,-3.5])
        mesh=stage.GetPrimAtPath(body.GetPath().AppendChild('Mesh'))
        assert UsdGeom.Imageable(mesh).GetVisibilityAttr().Get()=='invisible'
        assert UsdPhysics.CollisionAPI(mesh).GetCollisionEnabledAttr().Get()
        material=mesh.GetRelationship('material:binding').GetTargets()[0]
        color=stage.GetPrimAtPath(material.AppendChild('Surface')).GetAttribute('inputs:diffuseColor').Get()
        assert np.allclose(color,[.2,.4,.8])
    return {'parsed':True,'meshCount':len(meshes),'colliderCount':len(colliders),
            'bodyCount':len(bodies),'massKg':20,'physicsBindings':True,
            'courtyardsUseStaticTriangles':True,
            'editedTransformColorAndHiddenVisualPreserveCollider':edited}


results={'baseline':inspect(ROOT/'dist/exports/BrainSNN_Street_Studio.usda')}

# Independent support check against the serialized terrain triangles, rather
# than trusting the generator's support-plane metadata. Probe each surface's
# vertices, triangle centroids and all edge midpoints.
grid=SCENE['terrain']
heights=np.asarray(grid['heights']).reshape(grid['height'],grid['width'])
surface_results={}
for obj in SCENE['objects']:
    if obj['id'] not in {'street/test-lane','street/sidewalk-main','street/curb-main'}:
        continue
    vertices=np.asarray(obj['geometry']['positions']).reshape(-1,3)
    faces=np.asarray(obj['geometry']['indices']).reshape(-1,3)
    triangles=vertices[faces]
    probes=np.concatenate([vertices,triangles.mean(axis=1),
                           (triangles[:,0]+triangles[:,1])/2,
                           (triangles[:,1]+triangles[:,2])/2,
                           (triangles[:,2]+triangles[:,0])/2])
    u=(probes[:,0]-grid['originX'])/grid['cellSize']
    v=(probes[:,2]-grid['originZ'])/grid['cellSize']
    col=np.floor(u).astype(int).clip(0,grid['width']-2)
    row=np.floor(v).astype(int).clip(0,grid['height']-2)
    u-=col;v-=row
    h00=heights[row,col];h10=heights[row,col+1]
    h01=heights[row+1,col];h11=heights[row+1,col+1]
    supported=np.where(u+v<=1,h00+u*(h10-h00)+v*(h01-h00),
                        h11+(1-u)*(h01-h11)+(1-v)*(h10-h11))
    clearance=probes[:,1]-supported
    configured=obj['metadata']['configuredOffsetM']
    assert clearance.min()>configured-.00005
    assert clearance.max()<configured+.00005
    assert obj['metadata']['maxAlongSpacingM']<=1
    assert obj['metadata']['maxAcrossSpacingM']<=1
    assert obj['collider']['enabled'] and obj['collider']['static']
    surface_results[obj['id']]={'triangles':len(faces),'probeCount':len(probes),
        'configuredOffsetM':configured,'minimumClearanceM':float(clearance.min()),
        'maximumClearanceM':float(clearance.max()),'allProbesAboveTerrain':True,
        'samplingAtMostOneMetreAlongAndAcross':True}
assert len(surface_results)==3
results['terrainConformingSurfaces']=surface_results

with tempfile.TemporaryDirectory(prefix='brainsnn-usd-check-') as temp:
    target=pathlib.Path(temp)/'edited.usda'
    code="""
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.argv[1], target=process.argv[2];
const {exportSceneUSD}=await import(pathToFileURL(path.join(root,'dist/usd-export.mjs')));
const scene=JSON.parse(fs.readFileSync(path.join(root,'dist/assets/scene.json'),'utf8'));
const barrier=scene.objects.find(o=>o.id===scene.barrier.id);
barrier.transform.position=[12.25,1.125,-3.5];
barrier.material.color=[.2,.4,.8];
barrier.visible=false;
fs.writeFileSync(target,exportSceneUSD(scene));
"""
    subprocess.run(['node','--input-type=module','-e',code,str(ROOT),str(target)],check=True)
    results['live-edit']=inspect(target,edited=True)
gltf=trimesh.load(ROOT/'dist/exports/BrainSNN_Street_Studio.glb',force='scene')
assert len(gltf.geometry)==len(SCENE['objects'])
assert gltf.graph.transforms.parents['bldg-130159/window-001']=='bldg-130159'
results['glb']={'parsed':True,'meshCount':len(gltf.geometry),'actualParentHierarchy':True}
results['limits']='No Isaac Sim, Unreal, Unity, sensor or rigid-body runtime validation was performed.'
(ROOT/'asset_pipeline/validation.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
