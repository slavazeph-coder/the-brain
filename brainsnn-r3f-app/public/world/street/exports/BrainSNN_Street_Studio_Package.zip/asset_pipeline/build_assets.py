"""Build the bounded, object-based street studio from traceable local inputs.

All authored details are assumptions. Video has not been registered to this
scene. Coordinates: metres, X grid-east, Y up, Z minus grid-north.
Run with the packages in requirements.txt. The 2023 ground subset and municipal
GeoJSON are retained as compact reproducible inputs; no paid services are used.
"""
from __future__ import annotations

import collections
import hashlib
import json
import math
import pathlib
import re
import shutil
import struct

import laspy
import numpy as np
import pyproj
import scipy
from scipy.spatial import cKDTree
from shapely.geometry import Polygon, Point, shape
from shapely.ops import transform as shape_transform
from shapely.strtree import STRtree
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals
from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics, UsdShade, UsdSemantics, Vt

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / "dist/assets"
EXPORTS = ROOT / "dist/exports"
REF = ASSETS / "reference"
PRIOR = ROOT.parent / "geo_block_reference"
ORIGIN = [625341.0626837035, 4842330.960845888, 184.11]
MAIN_IDS = [130159, 130140, 130143]
OBJECTS = []
OBJECT_MESHES = {}
BUILDINGS = []
POLYGONS = {}
FEATURES = {}
BASES = {}
HEIGHTS = {}
MATERIALS = {
    "municipal-site-plan": {"color": [.70, .55, .37], "roughness": .9},
    "municipal-lidar-2015": {"color": [.37, .48, .55], "roughness": .95},
    "authored-brick": {"color": [.48, .235, .17], "roughness": .88},
    "authored-pale-brick": {"color": [.69, .60, .48], "roughness": .86},
    "authored-roof": {"color": [.17, .195, .22], "roughness": .9},
    "authored-window": {"color": [.11, .22, .29], "roughness": .28, "metalness": .10},
    "authored-frame": {"color": [.79, .80, .76], "roughness": .75},
    "authored-door": {"color": [.18, .23, .26], "roughness": .65},
    "authored-concrete": {"color": [.64, .64, .59], "roughness": .95},
    "terrain-2023": {"color": [.27, .34, .29], "roughness": 1.0},
    "authored-trunk": {"color": [.30, .22, .15], "roughness": 1.0},
    "authored-foliage": {"color": [.20, .39, .29], "roughness": 1.0},
    "authored-barrier": {"color": [.92, .47, .12], "roughness": .65},
}


def dump(path, data, pretty=False):
    path.write_text(json.dumps(data, indent=2 if pretty else None,
                               separators=None if pretty else (",", ":"),
                               allow_nan=False))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity():
    return {"position": [0, 0, 0], "rotation": [0, 0, 0], "scale": [1, 1, 1]}


def rounded(a):
    return np.asarray(a).round(5).tolist()


def local_mesh(mesh):
    return {"type": "mesh", "positions": rounded(mesh.vertices.reshape(-1)),
            "indices": mesh.faces.reshape(-1).tolist(), "flatShading": True}


def object_add(id, label, cls, mesh, *, parent=None, source="authored-assumed",
               material="authored-concrete", transform=None, collider=False,
               dynamic=False, metadata=None, geometry=None, editable=False):
    assert id not in OBJECT_MESHES, id
    m = {"name": material, "metalness": 0, **MATERIALS[material]}
    obj = {"id": id, "parentId": parent, "label": label, "class": cls,
           "sourceStatus": source, "geometry": geometry or local_mesh(mesh),
           "transform": transform or identity(), "transformSpace": "scene",
           "material": m,
           "collider": {"enabled": bool(collider),
                        "type": "convex-hull" if dynamic else "triangle-mesh",
                        "static": not dynamic, "staticFriction": .7,
                        "dynamicFriction": .55, "restitution": .05,
                        "parameterStatus": "configured-test-values"},
           "editable": editable,
           "editableProperties": ["position.x", "position.z"] if dynamic else
                                  (["material.color"] if source == "authored-assumed" else []),
           "metadata": metadata or {}}
    if dynamic:
        obj["collider"].update(massKg=20, massStatus="configured-assumption")
    if source == "authored-assumed":
        obj["metadata"].update(observed=False, registeredToVideo=False,
                              accuracyStatus="authored-demo-assumption",
                              sourceConfidence="unverified-authored")
    else:
        obj["metadata"].setdefault("sourceConfidence", "reference-data-current-site-unverified")
    assert np.isfinite(mesh.vertices).all() and len(mesh.faces) > 0
    OBJECTS.append(obj)
    OBJECT_MESHES[id] = mesh
    return obj


def make_box(dimensions, position, yaw=0):
    mesh = trimesh.creation.box(extents=dimensions)
    mat = trimesh.transformations.rotation_matrix(yaw, [0, 1, 0])
    mat[:3, 3] = position
    return mesh, mat


def box_add(id, label, cls, dimensions, position, yaw=0, **kwargs):
    mesh, _ = make_box(dimensions, position, yaw)
    return object_add(id, label, cls, mesh,
                      geometry={"type": "box", "dimensions": rounded(dimensions)},
                      transform={"position": rounded(position), "rotation": [0, yaw, 0], "scale": [1,1,1]},
                      **kwargs)


def world_mesh(obj):
    m = OBJECT_MESHES[obj["id"]].copy()
    t = obj["transform"]
    matrix = trimesh.transformations.euler_matrix(*t["rotation"], axes="sxyz")
    matrix[:3, 3] = t["position"]
    m.apply_transform(matrix)
    return m


def extrude(poly, height, base):
    # Input planar coordinates are X,Z. The intermediate extrusion is X,Z,Y.
    m = trimesh.creation.extrude_polygon(poly, height, engine="earcut")
    assert m.is_watertight and m.is_winding_consistent
    assert abs(abs(m.volume) - poly.area * height) < max(1e-6, poly.area * height * 1e-7)
    v = m.vertices.copy()
    m.vertices = np.column_stack([v[:, 0], v[:, 2] + base, v[:, 1]])
    # Swapping axes changes handedness: reverse triangles to keep outward normals.
    m.faces = m.faces[:, [0, 2, 1]]
    assert m.is_watertight and m.is_winding_consistent and m.volume > 0
    return m


def input_files():
    for folder in [ASSETS, EXPORTS, REF]:
        folder.mkdir(parents=True, exist_ok=True)
    pairs = [(PRIOR / "footprints/toronto-massing-2025-300m.geojson", REF / "municipal-massing-2025.geojson"),
             (PRIOR / "lidar/metadata.json", REF / "lidar-source-metadata.json"),
             (PRIOR / "footprints/reference-provenance.json", REF / "municipal-source-provenance.json")]
    for source, target in pairs:
        if not target.exists():
            shutil.copy2(source, target)
    ground = ROOT / "asset_pipeline/ground_patch.npz"
    if not ground.exists():
        samples = []
        with laspy.open(PRIOR / "lidar/toronto_block_20230511_full_resolution.laz") as reader:
            for chunk in reader.chunk_iterator(1_000_000):
                x = np.asarray(chunk.x) - ORIGIN[0]
                z = ORIGIN[1] - np.asarray(chunk.y)
                keep = (np.asarray(chunk.classification) == 2) & (x >= -79) & (x <= 54) & (z >= -59) & (z <= 69)
                samples.append(np.column_stack([x[keep], np.asarray(chunk.z)[keep] - ORIGIN[2], z[keep]]))
        np.savez_compressed(ground, xyz=np.concatenate(samples))
    return json.loads((REF / "municipal-massing-2025.geojson").read_text()), np.load(ground)["xyz"]


def terrain_make(points):
    x0, z0, cell, width, height = -75., -55., 2., 64, 61
    xx, zz = np.meshgrid(x0 + np.arange(width) * cell, z0 + np.arange(height) * cell)
    tree = cKDTree(points[:, [0, 2]])
    distances, indexes = tree.query(np.column_stack([xx.ravel(), zz.ravel()]), k=12)
    # Local ground sample median resists isolated classification errors. This is
    # a 2 m interpreted terrain grid, not the original full-resolution survey.
    yy = np.median(points[indexes, 1], axis=1)
    vertices = np.column_stack([xx.ravel(), yy, zz.ravel()])
    faces = []
    for row in range(height-1):
        for col in range(width-1):
            i = row*width+col
            faces.extend([[i, i+width, i+1], [i+1, i+width, i+width+1]])
    mesh = trimesh.Trimesh(vertices, faces, process=False)
    obj = object_add("terrain-2023-ground", "2023 ground · interpreted 2 m grid", "terrain", mesh,
                     source="lidar-2023", material="terrain-2023", collider=True,
                     metadata={"groundClass": 2, "sampleCount": len(points),
                               "method": "median of twelve nearest classified-ground returns per grid node",
                               "interpolation": True, "maximumNearestSampleDistanceM": float(distances[:,0].max()),
                               "observedDate": "2023-04-11", "verticalDatum": "CGVD2013, EPSG:6647",
                               "underBuildings": "surface interpolated where ground returns are sparse; not verified basement/foundation geometry"})
    obj["geometry"]["flatShading"] = False
    grid = {"originX": x0, "originZ": z0, "cellSize": cell, "width": width,
            "height": height, "heights": rounded(yy), "order": "row-major: z then x",
            "sourceStatus": "lidar-2023", "objectId": obj["id"], "sampleCount": len(points),
            "interpolated": True, "verticalBaselineM": ORIGIN[2]}
    return grid


def terrain_y(grid, x, z):
    u = np.clip((x-grid["originX"])/grid["cellSize"], 0, grid["width"]-1)
    v = np.clip((z-grid["originZ"])/grid["cellSize"], 0, grid["height"]-1)
    a, b = int(u), int(v)
    c, d = min(a+1, grid["width"]-1), min(b+1, grid["height"]-1)
    h = np.asarray(grid["heights"]).reshape(grid["height"], grid["width"])
    return float((1-u+a)*(1-v+b)*h[b,a]+(u-a)*(1-v+b)*h[b,c]+(1-u+a)*(v-b)*h[d,a]+(u-a)*(v-b)*h[d,c])


def buildings_make(data, terrain):
    projection = pyproj.Transformer.from_crs(4326, 2958, always_xy=True)
    def project(lon, lat, zz=None):
        e, n = projection.transform(lon, lat)
        return np.asarray(e)-ORIGIN[0], ORIGIN[1]-np.asarray(n)
    for feature in data["features"]:
        props = feature["properties"]
        fid = int(props["source_record_index"])
        id = f"bldg-{fid}"
        shp = shape_transform(project, shape(feature["geometry"]))
        assert shp.is_valid
        polygons = list(shp.geoms) if shp.geom_type == "MultiPolygon" else [shp]
        POLYGONS[fid], FEATURES[fid] = polygons, props
        h = float(props["AVG_HEIGHT"])
        assert math.isfinite(h) and h > 0
        # Vertical placement is authored from the reference terrain; original
        # municipal Z=0 and AVG_HEIGHT have no confirmed absolute vertical datum.
        if fid in MAIN_IDS:
            ring = np.concatenate([np.asarray(p.exterior.coords) for p in polygons])
            base = float(np.median([terrain_y(terrain, x, z) for x,z in ring]))
            placement = "assumed placement: median interpreted 2023 terrain at footprint vertices"
        else:
            base = 0.
            placement = "context-only flat baseline; no terrain or as-built alignment"
        BASES[fid], HEIGHTS[fid] = base, h
        mesh = trimesh.util.concatenate([extrude(p, h, base) for p in polygons])
        status = "municipal-site-plan" if props["HEIGHT_SRC"] == "Site Plan" else "municipal-lidar-2015"
        object_add(id, f"Municipal form {fid}" + (" · detailed frontage" if fid==130159 else ""),
                   "building", mesh, source=status, material=status, collider=True,
                   metadata={"sourceRecordIndex": fid, "sourceRelease": "2025",
                             "heightSource": props["HEIGHT_SRC"], "footprintSource": props["BLDG_SRC"],
                             "heightM": h, "baseY": base, "verticalPlacement": placement,
                             "observationDate": props.get("actual_observation_date"),
                             "asBuiltVerified": False, "videoAligned": False,
                             "role": "hero" if fid==130159 else "neighbor" if fid in MAIN_IDS else "context",
                             "courtyardCount": sum(len(p.interiors) for p in polygons),
                             "collisionGeometry": "exact triangulated footprint extrusion with interior rings preserved"})
        BUILDINGS.append({"id": id, "baseY": base, "height": h,
                          "polygons": [{"outer": rounded(p.exterior.coords),
                                        "holes": [rounded(r.coords) for r in p.interiors]} for p in polygons]})


def frontage(fid):
    p = POLYGONS[fid][0].simplify(.75, preserve_topology=True)
    ring = np.array(p.exterior.coords)
    edges=[]
    for a,b in zip(ring[:-1],ring[1:]):
        length = np.linalg.norm(b-a)
        if length < 3: continue
        t = (b-a)/length
        n = np.array([-t[1],t[0]])
        mid=(a+b)/2
        if np.dot(n, mid-np.array(p.centroid.coords[0])) < 0: n=-n
        # Long outward-facing side nearest the supplied pin.
        facing = np.dot(n, -mid) / max(1e-6,np.linalg.norm(mid))
        edges.append((length * max(.05, facing), a,b,t,n,length))
    _, a,b,t,n,length=max(edges,key=lambda item:item[0])
    if t[0]<0: a,b,t=b,a,-t
    return a,b,t,n,length


def detail_frontage(fid, terrain, bays, floors):
    parent=f"bldg-{fid}"
    a,b,t,n,length=frontage(fid)
    yaw=math.atan2(-t[1],t[0])
    base, height=BASES[fid],HEIGHTS[fid]
    material="authored-brick" if fid==130159 else "authored-pale-brick"
    side = .11
    center=(a+b)/2+n*side
    box_add(parent+"/facade-front", "Authored façade finish", "facade",
            [length-.12,height-.12,.14], [center[0],base+height/2,center[1]],yaw,
            parent=parent, material=material,
            metadata={"description":"procedural finish plane; frontage simplified from source footprint; not a measured façade"})
    roofs = [extrude(p,.10,base+height+.015) for p in POLYGONS[fid]]
    object_add(parent+"/roof", "Authored flat roof cap", "roof", trimesh.util.concatenate(roofs),
               parent=parent,material="authored-roof",
               metadata={"description":"flat cap follows source outline and preserves courtyards; actual roof profile unknown"})
    # Windows are individual selectable components. The shared trim is a single
    # mesh so object counts stay useful rather than turning every strip into an asset.
    frames=[]
    win_count=0
    unit=length/bays
    window_height=min(1.55, height/floors*.5)
    for bay in range(bays):
        for floor in range(floors):
            offsets=[.70] if floor==0 else [.30,.70]
            for off in offsets:
                u=(bay+off)*unit
                pos2=a+t*u+n*.215
                cy=base+1.8+floor*(height/floors)
                if cy+window_height/2>base+height-.35: continue
                w=min(2.0,unit*.24)
                win_count+=1
                box_add(parent+f"/window-{win_count:03d}",f"Authored window {win_count}","window",
                        [w,window_height,.10],[pos2[0],cy,pos2[1]],yaw,
                        parent=parent,material="authored-window",
                        metadata={"operable":False,"appearance":"procedural colour; no photo texture; dimensions assumed"})
                # Composite trim follows local window axes.
                for dimensions,delta in [([w+.16,.08,.13],[0,-window_height/2-.04,0]),
                                         ([w+.16,.08,.13],[0,window_height/2+.04,0]),
                                         ([.08,window_height,.13],[-w/2-.04,0,0]),
                                         ([.08,window_height,.13],[w/2+.04,0,0]),
                                         ([.055,window_height,.15],[0,0,0])]:
                    piece=trimesh.creation.box(extents=dimensions)
                    matrix=trimesh.transformations.rotation_matrix(yaw,[0,1,0])
                    local=np.array(delta)
                    matrix[:3,3]=np.array([pos2[0],cy,pos2[1]])+matrix[:3,:3]@local
                    piece.apply_transform(matrix)
                    frames.append(piece)
        u=(bay+.30)*unit
        door2=a+t*u+n*.23
        door_h=2.25
        box_add(parent+f"/door-{bay+1:02d}",f"Authored door {bay+1}","door",
                [1.05,door_h,.15],[door2[0],base+door_h/2+.12,door2[1]],yaw,
                parent=parent,material="authored-door",
                metadata={"operable":False,"description":"decorative door on a solid reference shell; no traversable interior is claimed"})
        if fid==130159:
            step2=a+t*u+n*.85
            ground=terrain_y(terrain,*step2)
            step_h=max(.10,min(.28,base-ground+.12))
            box_add(parent+f"/step-{bay+1:02d}",f"Authored entrance step {bay+1}","step",
                    [1.5,step_h,1.10],[step2[0],ground+step_h/2+.02,step2[1]],yaw,
                    parent=parent,collider=True,material="authored-concrete")
    object_add(parent+"/window-trim", "Authored window frames", "window-frame",
               trimesh.util.concatenate(frames),parent=parent,material="authored-frame")
    # Two thin end façade panels for the hero, following exact short source edges.
    if fid==130159:
        for side_index,(e,f) in enumerate(zip(np.asarray(POLYGONS[fid][0].exterior.coords)[:-1],np.asarray(POLYGONS[fid][0].exterior.coords)[1:])):
            edge=f-e; le=np.linalg.norm(edge)
            if le>20: continue
            yaw2=math.atan2(-edge[1],edge[0]); midpoint=(e+f)/2
            box_add(parent+f"/facade-end-{side_index}","Authored end façade","facade",
                    [le-.10,height-.12,.10],[midpoint[0],base+height/2,midpoint[1]],yaw2,
                    parent=parent,material=material)
    return {"a":rounded(a),"b":rounded(b),"tangent":rounded(t),"outward":rounded(n),"length":float(length),"yaw":yaw}


def strips_and_props(front, terrain):
    a=np.array(front["a"]);t=np.array(front["tangent"]);n=np.array(front["outward"])
    length=front["length"]; yaw=front["yaw"]
    # Overlay every <=1 m ribbon cell with the actual terrain triangles. Merely
    # sampling the two outside edges can bridge a slope break and intersect the
    # terrain between them; even a regular dense grid can straddle a terrain
    # triangle edge. Clipping makes every output face coplanar with precisely
    # one supporting terrain face, then raises it by a positive fixed offset.
    ground_mesh=OBJECT_MESHES["terrain-2023-ground"]
    ground_faces=ground_mesh.vertices[ground_mesh.faces]
    ground_polygons=[Polygon(face[:,[0,2]]) for face in ground_faces]
    ground_index=STRtree(ground_polygons)
    ground_normals=ground_mesh.face_normals
    coefficients=np.column_stack([
        -ground_normals[:,0]/ground_normals[:,1],
        -ground_normals[:,2]/ground_normals[:,1],
        ground_faces[:,0,1]+(ground_normals[:,0]*ground_faces[:,0,0]+
                             ground_normals[:,2]*ground_faces[:,0,2])/ground_normals[:,1],
    ])
    def strip(id,label,cls,distance,width,lift,material):
        along=np.linspace(1,length-1,math.ceil(length-2)+1)
        across=np.linspace(distance-width/2,distance+width/2,math.ceil(width)+1)
        vertices=[];faces=[];support_faces=[];projected_area=0.
        maximum_clearance_error=0.
        for s0,s1 in zip(along[:-1],along[1:]):
            for v0,v1 in zip(across[:-1],across[1:]):
                cell=Polygon([a+t*s0+n*v0,a+t*s1+n*v0,
                              a+t*s1+n*v1,a+t*s0+n*v1])
                for terrain_index in sorted(ground_index.query(cell).tolist()):
                    clipped=cell.intersection(ground_polygons[terrain_index])
                    pieces=list(clipped.geoms) if clipped.geom_type in {"MultiPolygon","GeometryCollection"} else [clipped]
                    for piece in pieces:
                        if piece.geom_type!="Polygon" or piece.area<1e-10:
                            continue
                        piece=piece.simplify(1e-10,preserve_topology=True)
                        xy,triangles=trimesh.creation.triangulate_polygon(piece,engine="earcut")
                        plane=coefficients[terrain_index]
                        heights=xy[:,0]*plane[0]+xy[:,1]*plane[1]+plane[2]+lift
                        patch=np.column_stack([xy[:,0],heights,xy[:,1]])
                        offset=len(vertices)
                        vertices.extend(patch.tolist())
                        # X,Z polygon winding becomes the opposite Y-up winding.
                        faces.extend((triangles[:,[0,2,1]]+offset).tolist())
                        support_faces.extend([terrain_index]*len(triangles))
                        projected_area+=piece.area
                        maximum_clearance_error=max(maximum_clearance_error,float(np.max(np.abs(
                            patch[:,1]-(patch[:,0]*plane[0]+patch[:,2]*plane[1]+plane[2])-lift))))
        mesh=trimesh.Trimesh(vertices,faces,process=False)
        assert len(mesh.faces)>0 and (mesh.face_normals[:,1]>.01).all()
        expected_area=(length-2)*width*abs(np.linalg.det(np.column_stack([t,n])))
        assert abs(projected_area-expected_area)<expected_area*1e-7
        assert maximum_clearance_error<1e-7
        ribbon_geometry=local_mesh(mesh)
        # Retain small clipped boundary pieces without rounding distinct
        # vertices together. This is serialization precision, not accuracy.
        ribbon_geometry["positions"]=mesh.vertices.reshape(-1).round(8).tolist()
        object_add(id,label,cls,mesh,collider=True,material=material,geometry=ribbon_geometry,
                   metadata={"layoutStatus":"authored test alignment",
                             "supportHeight":"exact underlying 2023 terrain triangle plus configured vertical offset",
                             "supportMethod":"<=1m ribbon cells clipped at every terrain triangle boundary",
                             "maxAlongSpacingM":float(np.diff(along).max()),
                             "maxAcrossSpacingM":float(np.diff(across).max()),
                             "configuredOffsetM":lift,
                             "minimumTerrainClearanceM":lift-maximum_clearance_error,
                             "maximumTerrainClearanceM":lift+maximum_clearance_error,
                             "projectedAreaM2":projected_area,
                             "triangleCount":len(mesh.faces),
                             "supportTriangleCount":len(set(support_faces)),
                             "walkable":True})
    strip("street/sidewalk-main","Authored test sidewalk","sidewalk",4.4,2.4,.10,"authored-concrete")
    strip("street/curb-main","Authored curb strip","curb",5.72,.22,.10,"authored-concrete")
    strip("street/test-lane","Authored walk/sim lane","road",8.2,4.6,.05,"authored-roof")
    # Trees are authored obstacles; none is labelled an observed individual tree.
    for index,u in enumerate([7.,45.],1):
        p=a+t*u+n*2.6; ground=terrain_y(terrain,*p)
        trunk=trimesh.creation.cylinder(radius=.18,height=3.2,sections=10)
        # trimesh cylinder is Z-up; turn to Y-up.
        trunk.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
        trunk.apply_translation([p[0],ground+1.6,p[1]])
        id=f"street/tree-{index:02d}"
        object_add(id,"Authored tree trunk","tree",trunk,collider=True,material="authored-trunk",
                   metadata={"locationStatus":"authored demonstration placement"})
        crown=trimesh.creation.icosphere(subdivisions=1,radius=1)
        crown.apply_scale([1.5,2.2,1.5]);crown.apply_translation([p[0],ground+4.,p[1]])
        object_add(id+"/crown","Authored tree canopy","tree-canopy",crown,parent=id,material="authored-foliage")
    start2=a+t*5.0+n*7.4;goal2=a+t*(length-5.)+n*7.4
    barrier2=a+t*(length*.52)+n*7.4
    barrier={"id":"street/movable-barrier","x":float(barrier2[0]),"z":float(barrier2[1]),
             "width":2.2,"depth":.65,"height":1.05,"yaw":yaw,"mass":20,
             "massKg":20,"sourceStatus":"authored-assumed","configured":True}
    y=terrain_y(terrain,*barrier2)+barrier["height"]/2+.025
    box_add(barrier["id"],"Movable barrier · configured 20 kg","barrier",
            [barrier["width"],barrier["height"],barrier["depth"]],
            [barrier2[0],y,barrier2[1]],yaw,collider=True,dynamic=True,
            material="authored-barrier",editable=True,
            metadata={"massKg":20,"massEvidence":"configured demonstration assumption",
                      "runtime":"browser navigation obstacle; exported rigid body requires a physics runtime"})
    barrier["y"]=y
    return {"x":float(start2[0]),"z":float(start2[1])},{"x":float(goal2[0]),"z":float(goal2[1])},barrier


def safe(value):
    return re.sub(r"[^A-Za-z0-9_]","_",value)


def export_glb(scene_data):
    scene=trimesh.Scene()
    for obj in OBJECTS:
        if obj.get("visible",True) is False:
            continue
        mesh=OBJECT_MESHES[obj["id"]].copy()
        mesh.unmerge_vertices()
        mat=obj["material"]
        mesh.visual=TextureVisuals(material=PBRMaterial(name=mat["name"],
                    baseColorFactor=np.array(mat["color"]+[1.]),roughnessFactor=mat["roughness"],
                    metallicFactor=mat.get("metalness",0)))
        mesh.metadata={k:obj[k] for k in ["id","parentId","label","class","sourceStatus","collider","metadata"]}
        tr=obj["transform"]
        matrix=trimesh.transformations.euler_matrix(*tr["rotation"],axes="sxyz")
        matrix[:3,3]=tr["position"]
        # All building parents are identity at authoring time. Logical hierarchy
        # is also retained in extras, including for tree canopy parents.
        scene.add_geometry(mesh,node_name=obj["id"],geom_name=obj["id"],
                           parent_node_name=obj["parentId"],transform=matrix)
    scene.metadata={"title":scene_data["title"],"origin":scene_data["origin"],
                    "sourceStatus":"mixed reference and explicitly authored assumptions",
                    "videoAligned":False,"staticCollision": "see OpenUSD or scene.json; glTF does not standardize physics"}
    path=EXPORTS/"BrainSNN_Street_Studio.glb"
    path.write_bytes(trimesh.exchange.gltf.export_glb(scene,include_normals=True))
    header=struct.unpack("<III",path.read_bytes()[:12]);assert header==(0x46546c67,2,path.stat().st_size)
    reopened=trimesh.load(path,force="scene")
    assert len(reopened.geometry)==sum(o.get("visible",True) is not False for o in OBJECTS)
    return {"path":"exports/"+path.name,"bytes":path.stat().st_size,"sha256":sha(path),
            "meshCount":len(reopened.geometry),"triangleCount":sum(len(m.faces) for m in reopened.geometry.values()),
            "validated":"GLB v2 container and Trimesh reload; finite geometry; source mesh count matched"}


def export_usd(scene_data):
    path=EXPORTS/"BrainSNN_Street_Studio.usda"
    if path.exists(): path.unlink()
    stage=Usd.Stage.CreateNew(str(path))
    world=UsdGeom.Xform.Define(stage,"/World");stage.SetDefaultPrim(world.GetPrim())
    UsdGeom.SetStageUpAxis(stage,UsdGeom.Tokens.y);UsdGeom.SetStageMetersPerUnit(stage,1.)
    UsdPhysics.SetStageKilogramsPerUnit(stage,1.)
    stage.GetRootLayer().customLayerData={"title":scene_data["title"],"origin_json":json.dumps(scene_data["origin"]),
                                          "provenance":"Municipal references + 2023 LiDAR + authored demo details. Not registered to video; not verified current as-built."}
    physics=UsdPhysics.Scene.Define(stage,"/World/PhysicsScene")
    physics.CreateGravityDirectionAttr(Gf.Vec3f(0,-1,0));physics.CreateGravityMagnitudeAttr(9.81)
    physics.GetPrim().SetCustomDataByKey("configurationStatus","assumed test gravity and materials; no runtime sensor or dynamics validation")
    pmat=UsdShade.Material.Define(stage,"/World/Materials/ConfiguredContact")
    api=UsdPhysics.MaterialAPI.Apply(pmat.GetPrim())
    api.CreateStaticFrictionAttr(.7);api.CreateDynamicFrictionAttr(.55);api.CreateRestitutionAttr(.05)
    pmat.GetPrim().SetCustomDataByKey("parameterStatus","configured demonstration coefficients; unmeasured")
    visual={}
    for name,mat in MATERIALS.items():
        material=UsdShade.Material.Define(stage,"/World/Materials/"+safe(name))
        shader=UsdShade.Shader.Define(stage,material.GetPath().AppendChild("Surface"))
        shader.CreateIdAttr("UsdPreviewSurface")
        shader.CreateInput("diffuseColor",Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*mat["color"]))
        shader.CreateInput("roughness",Sdf.ValueTypeNames.Float).Set(mat["roughness"])
        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(),"surface")
        visual[name]=material
    paths={}
    for obj in OBJECTS:
        parent=paths.get(obj["parentId"],"/World")
        node_path=parent+"/"+safe(obj["id"].split("/")[-1])
        paths[obj["id"]]=node_path
        node=UsdGeom.Xform.Define(stage,node_path);prim=node.GetPrim()
        tr=obj["transform"]
        node.AddTranslateOp().Set(Gf.Vec3d(*tr["position"]))
        node.AddRotateXYZOp().Set(Gf.Vec3f(*np.degrees(tr["rotation"]).tolist()))
        prim.SetCustomDataByKey("stableId",obj["id"])
        prim.SetCustomDataByKey("parentId",obj["parentId"] or "")
        prim.SetCustomDataByKey("sourceStatus",obj["sourceStatus"])
        prim.SetCustomDataByKey("evidence",json.dumps(obj["metadata"]))
        UsdSemantics.LabelsAPI.Apply(prim,"class").CreateLabelsAttr([obj["class"]])
        UsdSemantics.LabelsAPI.Apply(prim,"source_status").CreateLabelsAttr([obj["sourceStatus"]])
        mesh=OBJECT_MESHES[obj["id"]]
        geom=UsdGeom.Mesh.Define(stage,node_path+"/Mesh")
        geom.CreatePointsAttr(Vt.Vec3fArray.FromNumpy(mesh.vertices.astype(np.float32)))
        geom.CreateFaceVertexCountsAttr([3]*len(mesh.faces))
        geom.CreateFaceVertexIndicesAttr(mesh.faces.reshape(-1).astype(int).tolist())
        geom.CreateSubdivisionSchemeAttr(UsdGeom.Tokens.none)
        geom.CreateOrientationAttr(UsdGeom.Tokens.rightHanded)
        if obj.get("visible",True) is False:
            # Rendering visibility does not remove or disable CollisionAPI.
            geom.CreateVisibilityAttr(UsdGeom.Tokens.invisible)
        geom.CreateNormalsAttr(Vt.Vec3fArray.FromNumpy(np.repeat(mesh.face_normals,3,axis=0).astype(np.float32)))
        geom.SetNormalsInterpolation(UsdGeom.Tokens.faceVarying)
        geom.CreateExtentAttr([Gf.Vec3f(*mesh.bounds[0]),Gf.Vec3f(*mesh.bounds[1])])
        binding=UsdShade.MaterialBindingAPI.Apply(geom.GetPrim())
        binding.Bind(visual[obj["material"]["name"]])
        if obj["collider"]["enabled"]:
            UsdPhysics.CollisionAPI.Apply(geom.GetPrim()).CreateCollisionEnabledAttr(True)
            approx="convexHull" if not obj["collider"]["static"] else "none"
            UsdPhysics.MeshCollisionAPI.Apply(geom.GetPrim()).CreateApproximationAttr(approx)
            binding.Bind(pmat,UsdShade.Tokens.weakerThanDescendants,"physics")
        if not obj["collider"]["static"]:
            UsdPhysics.RigidBodyAPI.Apply(prim).CreateRigidBodyEnabledAttr(True)
            UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(20.)
    stage.GetRootLayer().Save()
    reopened=Usd.Stage.Open(str(path));assert reopened
    meshes=[p for p in reopened.Traverse() if p.IsA(UsdGeom.Mesh)]
    colliders=[p for p in meshes if p.HasAPI(UsdPhysics.CollisionAPI)]
    bodies=[p for p in reopened.Traverse() if p.HasAPI(UsdPhysics.RigidBodyAPI)]
    assert len(meshes)==len(OBJECTS) and len(bodies)==1
    assert UsdPhysics.MassAPI(bodies[0]).GetMassAttr().Get()==20.
    assert UsdGeom.GetStageMetersPerUnit(reopened)==1.
    assert UsdGeom.GetStageUpAxis(reopened)=="Y"
    # The actual static colliders retain triangle meshes. Convex hulls would fill
    # the municipal courtyards, so enforce that none is assigned to a building.
    for p in colliders:
        if p.GetParent().GetCustomDataByKey("stableId").startswith("bldg-"):
            assert UsdPhysics.MeshCollisionAPI(p).GetApproximationAttr().Get()=="none"
    return {"path":"exports/"+path.name,"bytes":path.stat().st_size,"sha256":sha(path),
            "meshCount":len(meshes),"collisionMeshCount":len(colliders),"dynamicBodyCount":len(bodies),
            "configuredBarrierMassKg":20,"usdVersion":".".join(map(str,Usd.GetVersion())),
            "validated":"Parsed with usd-core; mesh counts, Y-up metres, explicit collision APIs, 20 kg body, physics material bindings and hole-preserving static mesh approximations checked",
            "runtimeValidation":"not run in Isaac Sim, Unreal or Unity; this is an authored interchange scene, not a certified simulator"}


def main():
    data,ground=input_files()
    terrain=terrain_make(ground)
    buildings_make(data,terrain)
    front=detail_frontage(130159,terrain,6,3)
    detail_frontage(130140,terrain,6,3)
    detail_frontage(130143,terrain,1,3)
    start,goal,barrier=strips_and_props(front,terrain)
    source_urls={
       "municipal":"https://open.toronto.ca/dataset/3d-massing/",
       "municipalLicense":"https://open.toronto.ca/open-data-licence/",
       "lidar":"https://canelevation-lidar-point-clouds.s3.ca-central-1.amazonaws.com/pointclouds_nuagespoints/TRCA/GTA_2023/ON_TRCA2023_20230511_NAD83CSRS_UTMZ17_1km_E6250_N48420_CLASS.copc.laz",
       "lidarLicense":"https://open.canada.ca/en/open-government-licence-canada",
       "collisionSchema":"https://docs.omniverse.nvidia.com/kit/docs/omni_physics/latest/dev_guide/rigid_bodies_articulations/collision.html",
       "semanticSchema":"https://openusd.org/release/api/class_usd_semantics_labels_a_p_i.html"}
    bounds={"minX":-75,"maxX":51,"minZ":-55,"maxZ":65}
    scene={"schemaVersion":"brainsnn.street-studio/1.0","version":"0.1.0",
      "title":"BrainSNN · Street Studio","subtitle":"An editable, provenance-aware first frontage",
      "origin":{"latitude":43.7234276,"longitude":-79.4438620,"horizontalCrs":"EPSG:2958",
                "easting":ORIGIN[0],"northing":ORIGIN[1],"verticalDatum":"CGVD2013 / EPSG:6647",
                "verticalBaselineM":ORIGIN[2],"units":"metres","axes":{"x":"grid east","y":"up","z":"minus grid north"},
                "equations":{"x":"easting - 625341.0626837035","y":"orthometric elevation - 184.11","z":"4842330.960845888 - northing"},
                "municipalVerticalPlacement":"not a source vertical datum; hero bases are explicitly authored placements using interpreted 2023 terrain"},
      "materials":MATERIALS,"objects":OBJECTS,"buildings":BUILDINGS,"terrain":terrain,
      "bounds":bounds,"focusBounds":{"minX":-52,"maxX":24,"minZ":-31,"maxZ":46},
      "mainBuildingId":"bldg-130159","focusBuildingIds":[f"bldg-{i}" for i in MAIN_IDS],
      "camera":{"position":[34,37,43],"target":[-18,3,1]},"frontage":front,
      "start":start,"goal":goal,"barrier":barrier,
      "nav":{"bounds":bounds,"cellSize":.5,"agentRadius":.42,"agentHeight":.9,
             "playerRadius":.30,"playerHeight":1.8,
             "maxSlopeDegrees":20,"maxStepHeight":.25,"configured":True,
             "note":"2D navigation demonstration with terrain support; not a dynamics, accessibility or real robot safety validation"},
      "provenance":{"videoRegistered":False,"asBuiltVerified":False,
          "summary":"168 municipal reference forms; 3 with authored components; bounded 2023 ground terrain; no extracted Google imagery or invented photo matches",
          "municipal":"City of Toronto 2025 release: site-plan heights or 2015 LiDAR-derived heights; actual per-feature observation date unknown",
          "lidar":"TRCA / Natural Resources Canada, GTA_2023; cropped GPS timestamps 11 April 2023; filename date 11 May is project acquisition endpoint",
          "authored":"Façade finishes, roof caps, windows, doors, steps, sidewalk/curb, test lane, trees and barrier are authored assumptions; no video registration or current-site verification",
          "physics":"Static triangle meshes preserve courtyard holes; one configured 20 kg movable barrier; material coefficients are test settings",
          "limitations":["No building interiors; doors are decorative and not traversable.",
                         "Municipal site-plan forms can differ from the 2023 LiDAR and the current site.",
                         "2 m terrain is interpolated from classified-ground returns; it does not measure curbs or small obstacles.",
                         "Context building bases outside the test patch use a flat zero baseline.",
                         "GLB contains visuals, IDs and provenance; explicit physics and semantic APIs are in OpenUSD.",
                         "The phone video remains a separate, unregistered reference."],
          "attribution":["Contains information licensed under the Open Government Licence – Toronto. City of Toronto 3D Massing, 2025 release.",
                         "Contains information licensed under the Open Government Licence – Canada. Toronto and Region Conservation Authority LiDAR, distributed by Natural Resources Canada (CanElevation), GTA_2023."],
          "sources":source_urls}}
    scene["navigationObstacles"]=[]
    for obj in OBJECTS:
        if obj["class"]=="tree":
            box=world_mesh(obj).bounds
            middle=box.mean(axis=0);size=box[1]-box[0]
            scene["navigationObstacles"].append({"id":obj["id"],"x":float(middle[0]),"z":float(middle[2]),
                "width":float(size[0]),"depth":float(size[2]),"height":float(size[1]),
                "baseY":float(box[0,1]),"yaw":0.,"sourceStatus":"authored-assumed"})
    # Publish the browser contract before running exports, allowing independent
    # viewer/navigation development against the exact generated payload.
    dump(ASSETS/"scene.json",scene)
    glb=export_glb(scene);usd=export_usd(scene)
    hole_count=sum(len(p.interiors) for values in POLYGONS.values() for p in values)
    manifest={"title":scene["title"],"version":scene["version"],"origin":scene["origin"],
              "counts":{"objects":len(OBJECTS),"buildings":len(BUILDINGS),"detailedBuildings":3,
                        "classes":dict(collections.Counter(o["class"] for o in OBJECTS)),
                        "sourceStatuses":dict(collections.Counter(o["sourceStatus"] for o in OBJECTS)),
                        "courtyardHolesPreserved":hole_count,"groundReturns":len(ground)},
              "files":{"glb":glb,"usd":usd},"provenance":scene["provenance"],
              "validation":{"uniqueStableIds":True,"allFiniteGeometry":True,"positiveMunicipalHeights":True,
                            "sourceFootprintsValidWithoutRepair":True,"courtyardVolumeChecksPassed":True,
                            "selectedReferenceIds":MAIN_IDS},
              "objectIndex":[{k:o[k] for k in ["id","parentId","label","class","sourceStatus","editable","metadata"]} for o in OBJECTS]}
    scene["provenance"]["exports"]={"glb":glb,"usd":usd}
    scene["provenance"]["counts"]=manifest["counts"]
    dump(ASSETS/"scene.json",scene)
    dump(EXPORTS/"manifest.json",manifest,True)
    dump(REF/"terrain-grid.json",terrain)
    print(json.dumps({"scene":str(ASSETS/"scene.json"),"counts":manifest["counts"],"glb":glb,"usd":usd,"start":start,"goal":goal,"barrier":barrier,"frontage":front},indent=2))


if __name__=="__main__":
    main()
