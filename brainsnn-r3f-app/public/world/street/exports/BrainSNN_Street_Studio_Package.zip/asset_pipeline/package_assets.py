"""Package only the compact asset/export deliverable, never local dependencies."""
import hashlib
import json
import pathlib
import zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
TARGET=ROOT/'dist/exports/BrainSNN_Street_Studio_Package.zip'
names=[
    'dist/exports/BrainSNN_Street_Studio.glb',
    'dist/exports/BrainSNN_Street_Studio.usda',
    'dist/exports/manifest.json',
    'dist/assets/scene.json',
    'dist/usd-export.mjs',
    'asset_pipeline/build_assets.py',
    'asset_pipeline/validate_exports.py',
    'asset_pipeline/package_assets.py',
    'asset_pipeline/requirements.txt',
    'asset_pipeline/README.md',
    'asset_pipeline/PACKAGE_README.md',
    'asset_pipeline/validation.json',
    'asset_pipeline/ground_patch.npz',
    'tests/export-contract.test.mjs',
]
names.extend(str(p.relative_to(ROOT)) for p in sorted((ROOT/'dist/assets/reference').iterdir()) if p.is_file())
files=[]
for name in sorted(names):
    path=ROOT/name
    assert path.is_file(),name
    assert 'python_deps' not in name and path.suffix.lower() not in {'.laz','.las'}
    content=path.read_bytes()
    files.append((name,content,hashlib.sha256(content).hexdigest()))
manifest={
    'title':'BrainSNN Street Studio model and source package',
    'version':'0.1.0',
    'containsInteractiveApp':False,
    'containsFullLidar':False,
    'containsInstalledDependencies':False,
    'groundSubsetIncludedForPortableBuild':True,
    'files':[{'path':name,'bytes':len(content),'sha256':checksum} for name,content,checksum in files],
}
with zipfile.ZipFile(TARGET,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    archive.writestr('README.md',(ROOT/'asset_pipeline/PACKAGE_README.md').read_bytes())
    archive.writestr('PACKAGE_MANIFEST.json',json.dumps(manifest,indent=2))
    for name,content,_ in files:
        archive.writestr(name,content)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(files)+2
    assert not any('python_deps' in n or n.endswith(('.laz','.las')) for n in archive.namelist())
    for name,_,checksum in files:
        assert hashlib.sha256(archive.read(name)).hexdigest()==checksum
print(json.dumps({'path':str(TARGET),'bytes':TARGET.stat().st_size,'files':len(files)+2,
                  'sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),
                  'validated':'ZIP CRC, explicit allowlist, file hashes and exclusions'},indent=2))
