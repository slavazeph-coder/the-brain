# Street Studio asset pipeline

This build produces a concrete, editable reference scene. It combines real
municipal footprints, a bounded terrain interpretation from real classified
ground points, and explicitly authored façade and street components. It is not
a photogrammetric reconstruction of the supplied phone video and is not a
verified present-day as-built model.

## Rebuild

Create a Python environment, install `requirements.txt`, then run:

```sh
python asset_pipeline/build_assets.py
```

The compact retained inputs are `ground_patch.npz` and the files in
`dist/assets/reference/`. `ground_patch.npz` contains 179,636 original classified
ground returns, stored as local X/Y/Z metres. The builder can recreate that
subset from the earlier local 600 m LAZ if available. It makes no network calls.
Local `python_deps/` is a development convenience and is not a deliverable.

Outputs are `dist/assets/scene.json`, `dist/assets/reference/terrain-grid.json`,
and `dist/exports/BrainSNN_Street_Studio.glb`, `.usda`, and `manifest.json`.
The browser `dist/usd-export.mjs` independently serializes the current edited
scene JSON as USDA; its output is parse-validated against usd-core.

## Coordinate and object contract

The unit is one metre. X points grid east, Y points up, Z points minus grid
north. The exact origin is WGS84 43.7234276, -79.4438620, projected to
EPSG:2958 easting 625341.0626837035, northing 4842330.960845888. The terrain
vertical baseline is 184.11 m in CGVD2013 (EPSG:6647). These are UTM grid
directions, not a claimed true local ENU frame.

Each object has a stable ID within this scene version, a logical `parentId`,
class, source status, geometry, scene-space transform, authored material, and
collision metadata. Municipal keys are frozen from the 2025 source record
indices. A future release needs identity reconciliation rather than assuming
row indices remain stable across municipal releases.

Mesh geometry stores flat `positions` and triangle `indices`; boxes store
`dimensions`. Transform position and Euler rotation are XYZ, with radians.
Building parents have identity transforms, so the scene-space child transforms
also compose correctly in the GLB/USD hierarchy. Structural transforms are
fixed in the demo. Only the barrier is movable. Authored material colors can be
edited without turning their geometry into observed evidence.

The main frontage is municipal form 130159. Forms 130140 and 130143 are the
neighboring detailed references. All three are site-plan references with an
unknown actual observation date. Their doors, windows, finish panels, and flat
roof caps are procedural assumptions. Decorative doors sit on a solid building
shell: they do not create access to an invented interior. No photo textures or
video-to-map correspondences are fabricated.

## Ground and placement

The 64 by 61 terrain grid is sampled every 2 m. Each node uses the median of
the twelve nearest class-2 LiDAR returns from a 133 by 128 m input subset.
This is an interpreted surface. Gaps beneath roofs are interpolated; small
curbs, steps, and walls are not measured by this grid. The modeled sidewalk,
curb strip, lane, trees, and barrier are authored test elements.

The sidewalk, curb strip and test lane use cells no larger than 1 m along or
across, clipped at every underlying terrain-triangle boundary. Each resulting
triangle follows its supporting terrain plane exactly, offset vertically by
0.10 m for sidewalk/curb or 0.05 m for the lane. This prevents the rendered
terrain from breaking through a broad planar ribbon. Their layout and offsets
remain authored assumptions. Logical navigation still uses the ground grid.

Source LiDAR is TRCA / NRCan GTA_2023. The cropped points' GPS timestamps
indicate 11 April 2023. The source filename uses 11 May 2023, the project
acquisition endpoint, according to the federal naming convention. The scene
does not assume the uploaded video was captured after this reference.

Municipal source Z is zero and its absolute vertical datum is unconfirmed.
The three detailed building bases are explicitly placed using the median
interpreted terrain at their outline vertices. Other context forms use the
flat local baseline. This is scene assembly, not observed ground registration
or reconciliation of older measurements with proposed plans.

## Physics and semantic export

GLB carries meshes, materials, named hierarchy and provenance in extras. glTF
does not standardize these physics settings. USDA carries real `UsdGeom.Mesh`
objects, `UsdPhysics.CollisionAPI`, mesh collision approximation, physics
material bindings, `UsdSemantics.LabelsAPI` class/source labels, and metre/Y-up
stage settings. Older runtimes may need a semantic-label adapter.

All buildings are static triangle mesh colliders. Interior courtyard rings
remain empty in the mesh, preserving all six source holes; no single convex
hull is substituted for a building. The barrier alone is a dynamic rigid body
with a convex box mesh, configured mass 20 kg. Static friction 0.7, dynamic
friction 0.55 and restitution 0.05 are configured test coefficients, not measured
surface properties. Gravity is configured at 9.81 m/s² in negative Y.

The browser runs a bounded navigation/collision demonstration. It does not run
Isaac Sim or a full rigid-body solver. The USD exporter is checked with
usd-core, but no claim is made that Isaac Sim, Unreal or Unity have executed
this scene, validated sensor outputs, or reproduced physical behavior.

Visibility is a visual setting. When `object.visible` is false, the live USD
export retains its mesh, collider API and enabled collision, while setting that
mesh's rendering `visibility` to `invisible`. Descendant components retain
their own visibility setting. The GLB visual export excludes hidden visuals;
it is not a physics substitute for the USD scene. Layer display filters in the
editor do not edit object evidence or physical behavior.

## Validation

The generator checks finite coordinates, positive heights, valid source
polygons, unique IDs, watertight source extrusions, winding, and the expected
volume after subtracting courtyard holes. It reopens the GLB and checks object
counts. It opens the USDA stage and checks mesh/collider counts, physics material
bindings, units, axis, triangle-mesh building colliders and the single 20 kg body.
These are data/export checks, not physical accuracy measurements.

Run the small JavaScript contract suite with
`node --test tests/export-contract.test.mjs`. With the Python dependencies
installed, `python asset_pipeline/validate_exports.py` independently parses the
baseline USD and a newly generated moved, recolored, hidden barrier export. It
checks that hiding a visual retains an enabled collider and records its results
in `asset_pipeline/validation.json`.

## Sources and attribution

- [City of Toronto 3D Massing](https://open.toronto.ca/dataset/3d-massing/),
  2025 release: 53 site-plan height references and 115 older LiDAR-derived height
  references. [Open Government Licence – Toronto](https://open.toronto.ca/open-data-licence/).
- [CanElevation source tile](https://canelevation-lidar-point-clouds.s3.ca-central-1.amazonaws.com/pointclouds_nuagespoints/TRCA/GTA_2023/ON_TRCA2023_20230511_NAD83CSRS_UTMZ17_1km_E6250_N48420_CLASS.copc.laz).
  TRCA, distributed by Natural Resources Canada.
  [Open Government Licence – Canada](https://open.canada.ca/en/open-government-licence-canada).
- [OpenUSD/Omniverse collision schema](https://docs.omniverse.nvidia.com/kit/docs/omni_physics/latest/dev_guide/rigid_bodies_articulations/collision.html).
- [OpenUSD semantic labels](https://openusd.org/release/api/class_usd_semantics_labels_a_p_i.html).
- [Trimesh polygon extrusion](https://trimesh.org/trimesh.creation.html).
- [Mapbox Earcut Python](https://github.com/skogler/mapbox_earcut_python).

Contains information licensed under the Open Government Licence – Toronto.
Contains information licensed under the Open Government Licence – Canada.
